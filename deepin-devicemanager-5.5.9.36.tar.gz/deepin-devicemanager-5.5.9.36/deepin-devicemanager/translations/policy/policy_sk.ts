<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Na čítanie informácií o hardvéri je potrebné overenie</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potvrdiť</translation>
    </message>
</context>
</TS>