<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Для читання даних щодо обладнання слід пройти розпізнавання</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Скасувати</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Підтвердження</translation>
    </message>
</context>
</TS>