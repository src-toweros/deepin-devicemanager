<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Pro načtení informací o hardware je zapotřebí se ověřit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Storno</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
</context>
</TS>