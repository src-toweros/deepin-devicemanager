<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Cal autenticació per llegir la informació del maquinari.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmeu-ho</translation>
    </message>
</context>
</TS>