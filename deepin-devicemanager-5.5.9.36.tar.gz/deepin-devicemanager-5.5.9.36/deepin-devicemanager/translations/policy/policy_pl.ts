<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Do odczytania informacji o sprzęcie wymagane jest uwierzytelnienie</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potwierdź</translation>
    </message>
</context>
</TS>