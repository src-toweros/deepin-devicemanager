<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Laitteistotietojen lukeminen edellyttää todennusta</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Vahvista</translation>
    </message>
</context>
</TS>