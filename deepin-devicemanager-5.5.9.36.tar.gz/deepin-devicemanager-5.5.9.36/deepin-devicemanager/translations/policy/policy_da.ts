<?xml version="1.0" ?><!DOCTYPE TS><TS language="da" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Der kræves autentifikation for at læse hardwareinformation</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Bekræft</translation>
    </message>
</context>
</TS>