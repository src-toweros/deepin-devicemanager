<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>讀取硬體訊息需要認證</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>認證</translation>
    </message>
</context>
</TS>