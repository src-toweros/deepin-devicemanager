<?xml version="1.0" ?><!DOCTYPE TS><TS language="sq" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Për të lexuar të dhëna hardware, lypset mirëfilltësim</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Ripohojeni</translation>
    </message>
</context>
</TS>