<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Идентификација је неопходна за преглед података о уеђајима</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Потврди</translation>
    </message>
</context>
</TS>