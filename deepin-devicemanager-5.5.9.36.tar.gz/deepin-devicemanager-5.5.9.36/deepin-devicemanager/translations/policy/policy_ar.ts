<?xml version="1.0" ?><!DOCTYPE TS><TS language="ar" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>المصادقة مطلوبة لقراءة معلومات الأجهزة</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>إلغاء</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>تأكيد</translation>
    </message>
</context>
</TS>