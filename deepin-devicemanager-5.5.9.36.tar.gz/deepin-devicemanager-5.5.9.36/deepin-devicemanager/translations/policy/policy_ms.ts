<?xml version="1.0" ?><!DOCTYPE TS><TS language="ms" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Pengesahihan diperlukan untuk membaca maklumat perkakasan</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Sahkan</translation>
    </message>
</context>
</TS>