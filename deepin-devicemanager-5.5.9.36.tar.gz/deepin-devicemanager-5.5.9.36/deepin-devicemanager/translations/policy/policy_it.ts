<?xml version="1.0" ?><!DOCTYPE TS><TS language="it" version="2.1">
<context>
    <name>policy</name>
    <message>
        <source>Authentication is required to read hardware information</source>
        <translation>Autenticazione necessaria per rilevare le componenti hardware del dispositivo</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Conferma</translation>
    </message>
</context>
</TS>