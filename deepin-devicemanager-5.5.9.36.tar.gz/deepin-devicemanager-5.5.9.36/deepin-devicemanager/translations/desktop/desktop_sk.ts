<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>Správca zariadení je užitočný nástroj na prezeranie informácií o hardvéri a na správu zariadení.</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>Správca zariadení</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>Deepin Správca zariadení</translation>
</message>
</context>
</TS>