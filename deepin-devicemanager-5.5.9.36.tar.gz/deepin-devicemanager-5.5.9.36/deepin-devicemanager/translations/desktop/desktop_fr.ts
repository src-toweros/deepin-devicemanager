<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>Gestionnaire de périphériques est un outil pratique pour gérer et afficher les informations des composants et des périphériques</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>Gestionnaire de périphériques</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>Gestionnaire de périphériques Deepin</translation>
</message>
</context>
</TS>