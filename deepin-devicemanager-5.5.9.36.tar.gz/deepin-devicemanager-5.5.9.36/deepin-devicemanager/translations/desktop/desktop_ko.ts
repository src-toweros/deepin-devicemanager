<?xml version="1.0" ?><!DOCTYPE TS><TS language="ko" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>장치 관리자는 하드웨어 정보를 보고 장치를 관리하기 위한 편리한 도구입니다.</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>장치 관리자</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>Deepin 장치 관리자</translation>
</message>
</context>
</TS>