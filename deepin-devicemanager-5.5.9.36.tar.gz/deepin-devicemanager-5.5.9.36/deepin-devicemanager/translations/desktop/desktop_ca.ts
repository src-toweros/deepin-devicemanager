<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>El Gestor de dispositius és una eina pràctica per veure la informació del maquinari i gestionar els dispositius.</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>Gestor de dispositius</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>Gestor de dispositius del Deepin</translation>
</message>
</context>
</TS>