<?xml version="1.0" ?><!DOCTYPE TS><TS language="ar" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>مدير الأجهزة هو أداة مفيدة لعرض معلومات العتاد وإدارة الأجهزة</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>مدير الأجهزة</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>مدير أجهزة ديبين</translation>
</message>
</context>
</TS>