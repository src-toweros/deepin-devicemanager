<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>Administrador de dispositivos es una herramienta útil para ver la información de hardware y administrar los dispositivos.</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>Administrador de dispositivos</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>Administrador de dispositivos Deepin</translation>
</message>
</context>
</TS>