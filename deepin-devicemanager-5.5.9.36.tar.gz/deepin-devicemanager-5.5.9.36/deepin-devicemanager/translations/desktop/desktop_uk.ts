<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>«Керування пристроями» — зручний інструмент для перегляду відомостей щодо обладнання та керування пристроями.</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>Керування пристроями</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>Керування пристроями Deepin</translation>
</message>
</context>
</TS>