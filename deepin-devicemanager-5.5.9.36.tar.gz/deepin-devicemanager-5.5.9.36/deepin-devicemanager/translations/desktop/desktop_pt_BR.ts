<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>O Gerenciador de Dispositivos é uma ferramenta útil para visualizar as informações de hardware e gerenciar os dispositivos.</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>Gerenciador de Dispositivos</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>Deepin Gerenciador de Dispositivos</translation>
</message>
</context>
</TS>