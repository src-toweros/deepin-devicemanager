<?xml version="1.0" ?><!DOCTYPE TS><TS language="tr" version="2.1">
<context>
<name>desktop</name>
<message>
<location filename="Desktop Entry]Comment" line="0"/>
<source>Device Manager is a handy tool for viewing hardware information and managing the devices.</source>
<translation>Aygıt Yöneticisi, donanım bilgilerini görüntülemek ve aygıtları yönetmek için kullanışlı bir araçtır.</translation>
</message>
<message>
<location filename="Desktop Entry]GenericName" line="0"/>
<source>Device Manager</source>
<translation>Aygıt Yöneticisi</translation>
</message>
<message>
<location filename="Desktop Entry]Name" line="0"/>
<source>Deepin Device Manager</source>
<translation>Deepin Aygıt Yöneticisi</translation>
</message>
</context>
</TS>