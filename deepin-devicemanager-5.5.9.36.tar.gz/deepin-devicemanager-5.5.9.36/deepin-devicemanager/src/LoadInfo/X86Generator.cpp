#include "X86Generator.h"

X86Generator::X86Generator()
{

}
