#ifndef X86GENERATOR_H
#define X86GENERATOR_H

#include "DeviceGenerator.h"

class X86Generator : public DeviceGenerator
{
public:
    X86Generator();
};

#endif // X86GENERATOR_H
