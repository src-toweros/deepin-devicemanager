#include "ArmGenerator.h"

ArmGenerator::ArmGenerator()
{

}
