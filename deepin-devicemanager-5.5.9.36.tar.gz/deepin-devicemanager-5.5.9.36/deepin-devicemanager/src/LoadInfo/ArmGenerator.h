#ifndef ARMGENERATOR_H
#define ARMGENERATOR_H
#include "DeviceGenerator.h"

class ArmGenerator : public DeviceGenerator
{
public:
    ArmGenerator();
};

#endif // ARMGENERATOR_H
