#include "LoadDeviceInfo.h"

LoadDeviceInfo::LoadDeviceInfo(QObject *parent)
    : QObject(parent)
{

}
