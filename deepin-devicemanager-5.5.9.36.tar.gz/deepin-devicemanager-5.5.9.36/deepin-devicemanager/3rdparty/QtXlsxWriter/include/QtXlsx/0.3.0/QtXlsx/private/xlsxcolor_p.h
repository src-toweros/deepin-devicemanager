#include "../../../../../src/xlsx/xlsxcolor_p.h"
