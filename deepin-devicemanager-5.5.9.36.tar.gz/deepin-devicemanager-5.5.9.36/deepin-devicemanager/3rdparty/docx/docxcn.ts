<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en">
<context>
    <name>QObject</name>
    <message>
        <location filename="document.cpp" line="67"/>
        <source>Title</source>
        <translation>a4</translation>
    </message>
    <message>
        <location filename="document.cpp" line="69"/>
        <source>Heading%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="document.h" line="30"/>
        <source>TableGrid</source>
        <translation>a8</translation>
    </message>
</context>
</TS>
