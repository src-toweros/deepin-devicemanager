#include "coreproperties.h"

using namespace Docx;

CoreProperties::CoreProperties()
{

}

CoreProperties::~CoreProperties()
{

}

